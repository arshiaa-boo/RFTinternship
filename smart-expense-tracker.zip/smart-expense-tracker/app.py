"""
Bonus: Streamlit Dashboard
===========================
Interactive UI for the Smart Expense Tracker.

Run:
    streamlit run app.py
"""

import streamlit as st
import pandas as pd
import plotly.express as px

from expense_tracker import (
    load_transactions, add_categories, monthly_summary, budget_summary,
    DATA_FILE, MONTHLY_BUDGETS,
)
from predict_expenses import predict_next_month

st.set_page_config(page_title="Smart Expense Tracker", page_icon="💰", layout="wide")

st.title("💰 Smart Expense Tracker & Budget Analyzer")
st.caption("Day 29 — Python Internship Project")

# ---------------------------------------------------------------
# Data loading (upload your own CSV or use the bundled sample)
# ---------------------------------------------------------------
uploaded = st.sidebar.file_uploader("Upload transactions CSV", type="csv")
st.sidebar.markdown("CSV needs columns: `date, description, amount`")

if uploaded is not None:
    df = pd.read_csv(uploaded)
    df["date"] = pd.to_datetime(df["date"])
    df["amount"] = df["amount"].astype(float)
    df["month"] = df["date"].dt.to_period("M").astype(str)
else:
    df = load_transactions(DATA_FILE)
    st.sidebar.info("Using bundled sample data. Upload your own CSV to replace it.")

df = add_categories(df)

# ---------------------------------------------------------------
# Filters
# ---------------------------------------------------------------
months = sorted(df["month"].unique())
selected_months = st.sidebar.multiselect("Filter by month", months, default=months)
df_f = df[df["month"].isin(selected_months)]

# ---------------------------------------------------------------
# Top-line metrics
# ---------------------------------------------------------------
summary = monthly_summary(df_f)
total_income = summary["income"].sum()
total_expenses = summary["expenses"].sum()
total_savings = summary["savings"].sum()
avg_rate = summary["savings_rate_%"].mean() if len(summary) else 0

c1, c2, c3, c4 = st.columns(4)
c1.metric("Total Income", f"Rs {total_income:,.0f}")
c2.metric("Total Expenses", f"Rs {total_expenses:,.0f}")
c3.metric("Total Savings", f"Rs {total_savings:,.0f}")
c4.metric("Avg Savings Rate", f"{avg_rate:.1f}%")

st.divider()

# ---------------------------------------------------------------
# Charts
# ---------------------------------------------------------------
col1, col2 = st.columns(2)

with col1:
    st.subheader("Income vs Expenses vs Savings")
    fig = px.bar(summary, x="month", y=["income", "expenses"], barmode="group")
    fig.add_scatter(x=summary["month"], y=summary["savings"], mode="lines+markers", name="savings")
    st.plotly_chart(fig, use_container_width=True)

with col2:
    st.subheader("Spending by Category")
    exp = df_f[(df_f["amount"] < 0) & (df_f["category"] != "Income")].copy()
    exp["amount"] = -exp["amount"]
    cat_totals = exp.groupby("category")["amount"].sum().reset_index()
    fig2 = px.pie(cat_totals, names="category", values="amount", hole=0.35)
    st.plotly_chart(fig2, use_container_width=True)

st.subheader("Daily Spending Trend")
daily = df_f[df_f["amount"] < 0].groupby("date")["amount"].sum().abs().reset_index()
fig3 = px.area(daily, x="date", y="amount")
st.plotly_chart(fig3, use_container_width=True)

st.divider()

# ---------------------------------------------------------------
# Budget summary table
# ---------------------------------------------------------------
st.subheader("Budget vs Actual")
budget = budget_summary(df_f)
st.dataframe(
    budget.style.apply(
        lambda row: ["background-color:#ffebee" if row["status"] == "Over Budget" else "background-color:#e8f5e9"] * len(row),
        axis=1,
    ),
    use_container_width=True,
)

# ---------------------------------------------------------------
# Prediction
# ---------------------------------------------------------------
st.subheader("📈 Next Month Prediction")
if len(df_f["month"].unique()) >= 1:
    pred_df, total_predicted, _ = predict_next_month(df_f)
    st.write(f"**Predicted total spend next month: Rs {total_predicted:,.0f}**")
    st.dataframe(pred_df, use_container_width=True)
else:
    st.info("Not enough data to predict.")

st.divider()

# ---------------------------------------------------------------
# Raw data
# ---------------------------------------------------------------
with st.expander("View categorized transactions"):
    st.dataframe(df_f.sort_values("date", ascending=False), use_container_width=True)

st.download_button(
    "⬇️ Download categorized transactions (CSV)",
    df_f.to_csv(index=False).encode("utf-8"),
    file_name="categorized_transactions.csv",
    mime="text/csv",
)
